window.botpressWebChat.init({
  botId: '7f9dedb5-6e78-48a1-8805-3cf33764498b',
  clientId: 'db4082c5-8123-4935-88a1-ce4d389ac5aa',
  hostUrl: 'https://cdn.botpress.cloud/webchat/v3',
  messagingUrl: 'https://messaging.botpress.cloud',
  botName: 'Levi',
  showPoweredBy: false,
  startConversationOnMount: true,
  openByDefault: true,
  enableConversationDeletion: false,
  stylesheet: 'https://cdn.botpress.cloud/webchat/v3.0/themes/default.css'
})
